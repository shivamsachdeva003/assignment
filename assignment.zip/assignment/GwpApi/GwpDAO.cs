using System;
using System.Collections.Generic;
using GwpApi.Model;
using System.Linq;

namespace GwpApi
{
    public class GwpDAO
    {
        public double CountryGwp(GwpRequest gwpRequest)
        {
            try
            {
                using (var context = new GwpContext())
                {
                    var ans = context.Gwps.Where(e => e.country == gwpRequest.country && e.lineOfBusiness.Equals(gwpRequest.lineOfBusiness))
                                          .GroupBy(e => e.lineOfBusiness).Count();
                    if (ans<=0)
                    {
                        throw new Exception();
                    }
                    return ans;
                }
            }
            catch (System.Exception)
            {
                throw new Exception("Unable to find the  data");
            }
        }
    }
}
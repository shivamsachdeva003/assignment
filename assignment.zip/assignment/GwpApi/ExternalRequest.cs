using System.Collections.Generic;

namespace GwpApi
{
    public class ExternalRequest
    {
        public string country;
        public List<string> LinesOfBusiness;
    }
}
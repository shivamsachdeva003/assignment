using Xunit;
using GwpApi.Controllers;
using GwpApi;
using GwpApi.Model;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace emp_api.test
{

    public class EmpTest
    {
     
        [Fact]
        public void should_get_emp(){
            GwpDAO gwpDAO = new GwpDAO();
            GwpRequest gwpRequest =new GwpRequest();
            gwpRequest.country="ge";
            gwpRequest.lineOfBusiness="transport";
            var response = gwpDAO.CountryGwp(gwpRequest);
            Assert.IsNotNull(response);
        }

        [Fact]
        public void should_throw_exception(){
            GwpDAO gwpDAO = new GwpDAO();
            GwpRequest gwpRequest =new GwpRequest();
            Assert.Throws<Exception>(() => gwpDAO.CountryGwp(gwpRequest));
        }

    }
}
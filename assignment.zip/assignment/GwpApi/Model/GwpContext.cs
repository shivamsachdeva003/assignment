using Microsoft.EntityFrameworkCore;

namespace GwpApi.Model
{
    public partial class GwpContext : DbContext
    {
        public GwpContext()
        {
        }

        public GwpContext(DbContextOptions<GwpContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Gwp> Gwps { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                UseMySQL("Server=localhost;Uid=root;Pwd=Ritzzxi1.;Database=gwpByCountry;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Gwp>(entity =>
            {
                entity.ToTable("Gwp");

                entity.Property(e => e.Id).HasColumnName("Id");

                entity.Property(e => e.country)
                    .HasColumnName("country")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.variableId)
                    .HasColumnName("variableId")
                    .HasMaxLength(30)
                    .IsUnicode(false);
                entity.Property(e => e.variableName)
                    .HasColumnName("variableName")
                    .HasMaxLength(30)
                    .IsUnicode(false);
                entity.Property(e => e.lineOfBusiness)
                    .HasColumnName("lineOfBusiness")
                    .HasMaxLength(30)
                    .IsUnicode(false);
                entity.Property(e => e.Y2000).HasColumnName("Y2000");
                entity.Property(e => e.Y2000).HasColumnName("Y2001");
                entity.Property(e => e.Y2000).HasColumnName("Y2002");
                entity.Property(e => e.Y2000).HasColumnName("Y2003");
                entity.Property(e => e.Y2000).HasColumnName("Y2004");
                entity.Property(e => e.Y2000).HasColumnName("Y2005");
                entity.Property(e => e.Y2000).HasColumnName("Y2006");
                entity.Property(e => e.Y2000).HasColumnName("Y2007");
                entity.Property(e => e.Y2000).HasColumnName("Y2008");
                entity.Property(e => e.Y2000).HasColumnName("Y2009");
                entity.Property(e => e.Y2000).HasColumnName("Y2010");
                entity.Property(e => e.Y2000).HasColumnName("Y2011");
                entity.Property(e => e.Y2000).HasColumnName("Y2012");
                entity.Property(e => e.Y2000).HasColumnName("Y2013");
                entity.Property(e => e.Y2000).HasColumnName("Y2014");
                entity.Property(e => e.Y2000).HasColumnName("Y2015");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
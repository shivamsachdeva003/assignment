using System.Collections.Generic;

namespace GwpApi
{
    public class GwpResponse
    {
       public List<string> LinesOfBusiness;
       public List<double> LinesOfBusiness_Values;
    }
}
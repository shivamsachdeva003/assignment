using System;
using Xunit;

namespace GwpApi
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}

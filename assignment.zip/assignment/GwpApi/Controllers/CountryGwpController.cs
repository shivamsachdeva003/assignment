using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GwpApi.Model;

namespace GwpApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CountryGwpController : ControllerBase
    {
        private readonly GwpContext _context;

        public CountryGwpController(GwpContext context)
        {
            _context = context;
        }

        GwpDAO gwpDAO = new GwpDAO();

        [HttpPost]
        public async Task<ActionResult<GwpResponse>> PostGwp(ExternalRequest request)
        {
            GwpResponse gwpResponse = new GwpResponse();
            

           foreach(var lineOfBusiness in request.LinesOfBusiness)
           {
               GwpRequest gwpRequest = new GwpRequest();
               gwpRequest.country= request.country;
               gwpRequest.lineOfBusiness = lineOfBusiness;
               double ans = gwpDAO.CountryGwp(gwpRequest);
               gwpResponse.LinesOfBusiness.Add(lineOfBusiness);
               gwpResponse.LinesOfBusiness_Values.Add(ans);

           }

            return gwpResponse;
        }
    }
}

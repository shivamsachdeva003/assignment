using System.Collections.Generic;

namespace GwpApi
{
    public class GwpRequest
    {
        public string country;
        public string lineOfBusiness;
    }
}